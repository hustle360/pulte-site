ALTER TABLE `poll_submissions` ADD `q7` varchar(255);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q8` varchar(255);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q9` varchar(255);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q9_ages` varchar(255);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q10` varchar(255);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q11` varchar(255);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q12` varchar(255);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q13` varchar(255);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q14` varchar(512);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q15` varchar(255);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q16` varchar(512);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q17` varchar(255);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q18` varchar(255);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q18_other` varchar(255);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q19` varchar(512);--> statement-breakpoint
ALTER TABLE `poll_submissions` ADD `q20` varchar(255);